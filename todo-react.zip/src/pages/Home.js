import './Home.css';
import GroupTask from '../component/organism/GroupTask';
import React from 'react';
import Grid from '@material-ui/core/Grid';
import CreateAndDeleteTask from '../component/molecule/CreateAndDeleteTask';
import Modal from '@material-ui/core/Modal';

function Home(){
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };
    return(
        <div style={{display:"flex"}}>
            <div className ="rectangle">    
            </div>

            <div className ="content">
                <p>Product Roadmap</p>
                  <Grid container spacing = {0}>
                    <Grid style={{paddingLeft:"6px",paddingRight:"8px"}} item xs={3}>
                        <GroupTask nameGroupTask="Task1" month="Jan-Feb" onClickModal={handleOpen}/> 
                    </Grid>
                    <Grid style={{paddingLeft:"6px",paddingRight:"8px"}} item xs={3}>
                        <GroupTask nameGroupTask="Task1" month="Jan-Feb"/> 
                    </Grid>
                    <Grid style={{paddingLeft:"6px",paddingRight:"8px"}} item xs={3}>
                        <GroupTask nameGroupTask="Task1" month="Jan-Feb"/> 
                    </Grid>
                    <Grid style={{paddingLeft:"6px",paddingRight:"8px"}} item xs={3}>
                        <GroupTask nameGroupTask="Task1" month="Jan-Feb"/> 
                    </Grid>
                  </Grid>
                 
            </div> 
            {/* <CreateAndDeleteTask nameActivity="CreateTask" open={open} onClose={handleClose} /> */}
            <Modal
            open={true}></Modal>
        </div>
    );
}

export default Home;

